import UIKit
import Firebase

enum UploadFor {
    case post
    case profile
}

struct ImageUploader {
    
    static func uploadImage(image: UIImage, UploadFor: UploadFor,completion: @escaping(String) -> Void) {
        guard let imageData = image.jpegData(compressionQuality: 0.75) else {return }
        let filename = NSUUID().uuidString
        
        let ref = UploadFor == .post ? Storage.storage().reference(withPath: "/post_image/\(filename)") : Storage.storage().reference(withPath: "/profile_image/\(filename)")
        
        
        ref.putData(imageData, metadata: nil) { _, error in
            if error != nil {
                print("DEBUG: Error uploading image to store: \(error!.localizedDescription)")
                return
            }
            
            print("uploaded image successfully")
            ref.downloadURL { url, _ in
                guard let imageUrl = url?.absoluteString else {
                    return
                }
                completion(imageUrl)
            }
            
        }
    }
}
