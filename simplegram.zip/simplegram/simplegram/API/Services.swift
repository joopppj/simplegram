import Firebase

struct Services {
    
    static func follow(uid: String, completion: ((Error?) -> Void)?) {
        guard let currentUid = AuthenticationViewModel.shared.userSession?.uid else { return }
        
        COLLECTION_FOLLOWINGS.document(currentUid).collection("followings").document(uid).setData([:]) { _ in // [:] means we dont need any fields for every following/follower (only their uid is enough)
            COLLECTION_FOLLOWERS.document(uid).collection("followers").document(currentUid).setData([:], completion: completion)
        }
    }
        
    static func unfollow(uid: String, completion: ((Error?) -> Void)?) {
        guard let currentUid = AuthenticationViewModel.shared.userSession?.uid else { return }
    
        COLLECTION_FOLLOWINGS.document(currentUid).collection("followings").document(uid).delete { _ in
            COLLECTION_FOLLOWERS.document(uid).collection("followers").document(currentUid).delete(completion: completion)
        }
        
    }
    
    static func isProfileUserFllowed(uid: String, completion: @escaping(Bool) -> Void) { // to check if the profile is in following list (make the status persistant )
        guard let currentUid = AuthenticationViewModel.shared.userSession?.uid else { return }
        
        COLLECTION_FOLLOWINGS.document(currentUid).collection("followings").document(uid).getDocument { querySnapshot , _ in
            guard let isFollowed = querySnapshot?.exists else { return }
            
            completion(isFollowed)
        }
    }
}
