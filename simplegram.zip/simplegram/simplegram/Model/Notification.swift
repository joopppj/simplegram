import Firebase
import FirebaseFirestoreSwift

struct  Notification: Identifiable, Decodable {
    @DocumentID var id: String?
    let postId: String?
    let username: String
    let profileImageUrl: String
    let timestamp : Timestamp
    let type: NotificationType
    let uid:  String
    
    var userFollowedBack: Bool? = false
    var post: Post?
    
}

enum NotificationType: Int, Decodable {
    case like = 0
    case comment = 1
    case follow = 2
    
    var notificationMessage: String{
        switch self{
        case .like: return " liked one of your posts"
        case .comment: return " commented on one of your posts"
        case .follow: return " followed you"
        }
    }
    
    
}

