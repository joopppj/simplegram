import Foundation
import FirebaseFirestoreSwift
import Firebase

struct Post: Identifiable,Decodable{
    @DocumentID var id: String?
    let authorProfileImageUrl: String
    let authorUid: String
    let authorUsername: String
    let text: String
    var likes: Int
    let imageURL:String
    let timestamp: Timestamp
    
    var liked: Bool? = false
}
