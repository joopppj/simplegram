import Foundation
import FirebaseFirestoreSwift
import Firebase

struct Topic: Identifiable, Decodable {
    @DocumentID var id: String?
    let topicName: String
    
    
}
