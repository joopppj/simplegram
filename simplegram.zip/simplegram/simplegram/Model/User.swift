import Foundation
import FirebaseFirestoreSwift

struct User: Identifiable,Decodable{
    @DocumentID var id: String?
    let username: String
    let email: String
    let profileImageUrl: String
    let fullname: String
    //let uid: String
    var nums: userNumbers?
    var isFollowed: Bool? = false // if we make a property optional , it is okay to not have it in json
    
    var isCurrentUser: Bool{ return AuthenticationViewModel.shared.userSession?.uid == id}
    
}

struct userNumbers: Decodable {
    var postNum: Int
    var followingNum: Int
    var followerNum:Int
}
