
import SwiftUI

struct CustomTextField: View {
    @Binding var text: String
    @State var placeholder : Text
    let icon: String
    @State private var opacity: CGFloat = 0.8
    
    var body: some View {
        ZStack(alignment: .leading){
            /*placeholder.foregroundColor(Color(.init(white: 1, alpha: opacity )))
                .padding(.leading, 40)*/
            if text == "" {
                placeholder.foregroundColor(Color(.init(white: 1, alpha: opacity)))
                    .padding(.leading, 40)
            }
            HStack {
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height : 20)
                    .foregroundColor(.white)
                
                TextField("", text: $text)
                /*TextField("", text: $text, onEditingChanged: { hasChanged in
                    if hasChanged && self.text.isEmpty {
                        opacity = 0
                    } else if !hasChanged && self.text.isEmpty {
                        opacity = 0.8
                    }
                })*/
            }
        }
    }
}

