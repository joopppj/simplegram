

import SwiftUI

struct UploadTextEditor: View {
    @Binding var commentText: String
    let placeholder: String
    
    init(commentText: Binding<String>, placeholder: String) {
        self._commentText = commentText
        self.placeholder = placeholder
        UITextView.appearance().backgroundColor = .clear
    }
    var body: some View {
        ZStack(alignment: .topLeading){
            if commentText == "" {
                Text(placeholder)
                    .foregroundColor(Color(UIColor.placeholderText))
                    .padding(.horizontal, 8)
            }
            
            TextEditor(text: $commentText)
                .padding(4)
        }
        .font(.body)
    }
}

