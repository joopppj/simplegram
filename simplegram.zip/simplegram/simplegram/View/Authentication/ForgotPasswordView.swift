
import SwiftUI

struct ForgotPasswordView: View {
    
    
    @Binding private var email: String
    @State private var password = ""
    
    // firebase stuff
    @EnvironmentObject var viewModel: AuthenticationViewModel
    @Environment(\.presentationMode) private var presentationMode
    
    
    init(email: Binding<String>) {
        self._email = email
    }
    var body: some View {
        NavigationView{
            ZStack {
                AnimatedBackground2().edgesIgnoringSafeArea(.all).blur(radius: 10)
                VStack{
                    Image("simplegram_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 150)
                        .padding(.bottom)
                    
                    // email + password input
                    VStack {
                        CustomTextField(text: $email, placeholder: Text(""), icon: "envelope")
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                    }
                    
                    //sign in
                    Button(action: {
                        viewModel.resetPassword(withEmail: email)
                    }, label: {
                        Text("Reset Password")
                            .font(.title)
                            .foregroundColor(.white)
                            .frame(width: 260, height: 50)
                            .background(Color(.init(white: 1, alpha: 0.2)))
                    }).cornerRadius(100)
                    .padding(.top, 20)
                    
                    Spacer()
                    
                    NavigationLink(destination: LoginView()){
                        Button(action: {presentationMode.wrappedValue.dismiss()}, label: {
                            HStack {
                                Text("Already have an account?")
                                    .foregroundColor(.white)
                                Text("Sign in!")
                                    .font(.system(size: 14,weight:.bold))
                                    .foregroundColor(.white)
                            }
                        })
                    }
                    
                }.onReceive(viewModel.$sentResetPasswordLink, perform: { _ in
                    self.presentationMode.wrappedValue.dismiss()
                })
            }
        }
    }
}

struct AnimatedBackground2: View {
    @State var start = UnitPoint(x: 0, y: -4)
    @State var end = UnitPoint(x: 4, y: 0)
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    let colors = [Color.purple, Color.pink, Color.yellow]
    var body: some View {
        LinearGradient(gradient: Gradient(colors: colors), startPoint: start, endPoint: end)
            .animation(Animation.easeInOut(duration: 7).repeatForever(), value: start)
            .onReceive(timer, perform: { _ in
                    self.start = UnitPoint(x: 4, y: 0)
                    self.end = UnitPoint(x: 0, y: 2)
                    self.start = UnitPoint(x: 50, y: 100)
                    self.start = UnitPoint(x: 4, y: 0)
            })
    }
}

