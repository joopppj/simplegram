
import SwiftUI

struct LoginView: View {
  
    
    @State private var email = ""
    @State private var password = ""
    
    // firebase stuff
    @EnvironmentObject var viewModel: AuthenticationViewModel
    
    
    
    var body: some View {
        NavigationView{
            ZStack {
                AnimatedBackground().edgesIgnoringSafeArea(.all).blur(radius: 10)
                VStack{
                    Image("simplegram_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 150)
                        .padding(.bottom)
                    
                    // email + password input
                    VStack {
                        CustomTextField(text: $email, placeholder: Text("Email"), icon: "envelope")
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                        
                        
                        CustomSecureField(text: $password, placeholder: Text("Password"))
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                    }
                    
                    // cant remember password
                    
                    HStack {
                        NavigationLink(
                            destination: ForgotPasswordView(email: $email)
                                .navigationBarHidden(true),
                            label: {
                                Text("Can't remember password?")
                                    .font(.system(size:13, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.top, 20)
                                    .padding(.leading, 100)
                            })
                        
                    }
                    
                    //sign in
                    Button(action: {
                        //withAnimation{
                            viewModel.login(email: email, password: password)
                        //}
                    }, label: {
                        Text("Sign in")
                            .font(.title)
                            .foregroundColor(.white)
                            .frame(width: 260, height: 50)
                            .background(Color(.init(white: 1, alpha: 0.2)))
                    }).cornerRadius(100)
                    .padding(.top, 20)
                    
                    Spacer()
                    // sign up notification
                    NavigationLink(
                        destination: RegistrationView()
                            .navigationBarHidden(true),
                        label: {
                            HStack {
                                Text("Dont have an account?")
                                    .foregroundColor(.white)
                                Text("Sign up!")
                                    .font(.system(size: 14,weight:.bold))
                                    .foregroundColor(.white)
                            }
                        })
                    
                   
                    
                    
                    
                }
            }
        }
    }
}

struct AnimatedBackground: View {
    @State var start = UnitPoint(x: 0, y: -4)
    @State var end = UnitPoint(x: 4, y: 0)
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    let colors = [Color.blue, Color.purple, Color.pink, Color.yellow,Color.green]
    var body: some View {
        LinearGradient(gradient: Gradient(colors: colors), startPoint: start, endPoint: end)
            .animation(Animation.easeInOut(duration: 7).repeatForever(), value: start)
            .onReceive(timer, perform: { _ in
                    self.start = UnitPoint(x: 4, y: 0)
                    self.end = UnitPoint(x: 0, y: 2)
                    self.start = UnitPoint(x: 50, y: 100)
                    self.start = UnitPoint(x: 4, y: 0)
            })
    }
}

