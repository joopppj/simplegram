

import SwiftUI

struct RegistrationView: View {
    @State private var email = ""
    @State private var username = ""
    @State private var fullname = ""
    @State private var password = ""
    
    @Environment(\.presentationMode) private var presentationMode
    
    @State private var image : UIImage = UIImage()
    @State private var isShowPhotoLibrary = false
    
    //firebase stuff
    @EnvironmentObject var viewModel: AuthenticationViewModel
    
    var body: some View {
        NavigationView {
            ZStack {
                
                AnimatedBackground1().edgesIgnoringSafeArea(.all).blur(radius: 10)
                
                
                
                
                VStack{
                    if image == UIImage() {
                    Button(action: {isShowPhotoLibrary.toggle()}, label: {
                        Image(systemName: "photo")
                            .renderingMode(.template)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 130, height: 130)
                            .foregroundColor(Color(.init(white: 1, alpha: 0.6)))
                            .padding(.bottom, 50)
                    })
                    } else {
                        Image(uiImage: self.image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 100)
                            .clipShape(Circle())
                            .padding(.bottom,50)
                    }
                    
                    
                    
                    
                    
                    // email + password input
                    VStack {
                        CustomTextField(text: $email, placeholder: Text("Email"), icon: "envelope")
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                        
                        CustomTextField(text: $username, placeholder: Text("Username"), icon: "person")
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                        
                        CustomTextField(text: $fullname, placeholder: Text("Fullname"), icon: "person.crop.circle.badge.checkmark")
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                        
                        CustomSecureField(text: $password, placeholder: Text("Password"))
                            .padding()
                            .background(Color(.init(white: 1, alpha: 0.2)))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .padding(.horizontal, 40)
                    }.sheet(isPresented: $isShowPhotoLibrary, content: {
                        ImagePicker(sourceType: .photoLibrary, selectedImage: self.$image)
                    })
                 
                    //sign up
                    Button(action: {
                        viewModel.signup(email: email, username: username, password: password, image: image,fullname: fullname)
                        
                    }, label: {
                        Text("Sign up")
                            .font(.title)
                            .foregroundColor(.white)
                            .frame(width: 260, height: 50)
                            .background(Color(.init(white: 1, alpha: 0.2)))
                    }).cornerRadius(100)
                    .padding(.top, 20)
                    
                    Spacer()
                    // sign up notification
                    
                    Button(action: {presentationMode.wrappedValue.dismiss()}, label: {
                        HStack {
                            Text("Already have an account?")
                                .foregroundColor(.white)
                            Text("Sign in!")
                                .font(.system(size: 14,weight:.bold))
                                .foregroundColor(.white)
                        }
                    })
                }.sheet(isPresented: $isShowPhotoLibrary, content: {
                    ImagePicker(sourceType: .photoLibrary, selectedImage: self.$image)
                })
            }
        }
    }
}

struct AnimatedBackground1: View {
    @State var start = UnitPoint(x: 0, y: -4)
    @State var end = UnitPoint(x: 4, y: 0)
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    let colors = [Color.blue, Color.red, Color.purple, Color.pink, Color.yellow, Color.red]
    var body: some View {
        LinearGradient(gradient: Gradient(colors: colors), startPoint: start, endPoint: end)
            .animation(Animation.easeInOut(duration: 7).repeatForever(), value: start)
            .onReceive(timer, perform: { _ in
                    self.start = UnitPoint(x: 4, y: 0)
                    self.end = UnitPoint(x: 0, y: 2)
                    self.start = UnitPoint(x: 50, y: 100)
                    self.start = UnitPoint(x: 4, y: 0)
            })
    }
}
struct RegistrationView_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationView()
    }
}
