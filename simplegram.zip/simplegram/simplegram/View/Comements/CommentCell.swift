

import SwiftUI
import Kingfisher


struct CommentCell: View {
    let comment: Comment
    
    var timestampText: String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.second, .minute, .hour, .day]
        formatter.maximumUnitCount = 1
        formatter.unitsStyle = .short
        return formatter.string(from: comment.timestamp.dateValue(), to: Date()) ?? "" // difference between post time and now. // potential bug here , but looks fine now
    }
    
    var body: some View {
        HStack{
            KFImage(URL(string: comment.profileImageUrl))
                .resizable()
                .scaledToFill()
                .frame(width: 40, height: 40, alignment: .center)
                .clipShape(Circle())
            
            Text(comment.username).font(.system(size: 14, weight: .semibold)) +
                Text(" \(comment.commentText)").font(.system(size: 14))
            
            Spacer()
            
            Text(timestampText)
                .foregroundColor(.gray)
                .font(.system(size: 15))
        }.padding(.horizontal)
    }
}

