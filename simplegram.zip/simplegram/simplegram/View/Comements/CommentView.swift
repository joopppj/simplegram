
import SwiftUI

struct CommentView: View {
    @State var commentText = ""
    @ObservedObject var viewModel: CommentViewModel
    //private let post: Post
    init(post: Post) {
        self.viewModel = CommentViewModel(post: post)
    }
    var body: some View {
        
        VStack{
            // comment cells
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 16){
                    ForEach(viewModel.comments){comment in
                        CommentCell(comment: comment)
                    }
                }
            }.padding(.top)
            
            InputView(inputText: $commentText, action: sendComment)
        }
    }
    
    func sendComment() {
        viewModel.uploadComment(commentText: commentText)
        commentText = ""
    }
}

