
import SwiftUI
import Kingfisher
struct FeedCell: View {
    @ObservedObject var viewModel: FeedCellViewModel
    
    var liked: Bool {return viewModel.post.liked ?? false }
    
    
    init(viewModel: FeedCellViewModel) {
        self.viewModel = viewModel
    }
    var body: some View {
        VStack(alignment: .leading){
            // top
            
            // user info
            HStack{
                KFImage(URL(string: viewModel.post.authorProfileImageUrl))
                    .resizable()
                    .scaledToFill()
                    .frame(width: 36, height: 36)
                    .clipped()
                    .cornerRadius(18)
                
                Text(viewModel.post.authorUsername)
                    .font(.system(size: 18, weight: .semibold))
            }
            .padding([.leading],7)
            
            // image post
            KFImage(URL(string: viewModel.post.imageURL))
                .resizable()
                .scaledToFill()
                .frame(maxHeight: 210)
                .clipped()
            
            //buttons
            HStack(spacing: 15) {
                
                Button(action: {liked ? viewModel.unlike() : viewModel.like()}, label: {
                    Image(systemName: liked ? "heart.fill" : "heart")
                        .resizable()
                        .scaledToFill()
                        //.foregroundColor(viewModel.post.liked! ? .red : .blue)
                        .frame(width: 28, height: 28)
                        .font(.system(size: 20))
                        .padding(4)
                }).foregroundColor(.red)
                
                NavigationLink(
                    destination: CommentView(post: viewModel.post),
                    label: {
                        Image(systemName: "bubble.right")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 28, height: 28)
                            .font(.system(size: 20))
                            .padding(4)
                    })
                
                Button(action: {}, label: {
                    Image(systemName: "arrowshape.turn.up.left")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 28, height: 28)
                        .font(.system(size: 20))
                        .padding(4)
                })
            }
            .padding(.leading, 5)
            
            
            // text contents
            Text(viewModel.post.likes == 1 ? "1 like" : "\(viewModel.post.likes) likes ").padding(.leading, 10)
            
            HStack {
                Text("\(viewModel.post.authorUsername)  ").font(.system(size: 14, weight: .bold)) +
                    Text(viewModel.post.text)
                    .font(.system(size: 15))
            }
            .padding(.horizontal, 10)
            
            Text("\(viewModel.timestampText) ago")
                .font(.system(size: 14))
                .foregroundColor(.gray)
                .padding(.leading, 10)
        }
    }
}


