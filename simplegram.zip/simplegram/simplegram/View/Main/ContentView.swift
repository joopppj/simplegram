

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel: AuthenticationViewModel
    @State var selectingTab = 0
    var body: some View {
        Group {
            if viewModel.userSession == nil {
                LoginView()//.transition(.slide).animation(.easeIn)
            } else {
                if let user = viewModel.currentUser {
                    
                    MainTabView(user:user,selecteTab:$selectingTab)//.transition(.opacity).animation(.easeIn(duration: 0.5))
                    
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
