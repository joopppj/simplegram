//
//  MainTabView.swift
//  simplegram
//
//

import SwiftUI

struct MainTabView: View {
    
    let user: User
    
    @Binding var selecteTab: Int
    //@Binding var selecteColor: Color
    var body: some View {
        NavigationView {
            TabView(selection: $selecteTab){
                
                FeedView()
                    .onTapGesture {
                        selecteTab = 0
                    }
                    .tabItem {
                        Image(systemName: "flame")
                    }.tag(0)
                
                SearchView()
                    .onTapGesture {
                        selecteTab = 1
                    }
                    .tabItem {
                        Image(systemName: "magnifyingglass")
                    }.tag(1)
                
                UploadView(selectedTab: $selecteTab)
                    .onTapGesture {
                        selecteTab = 2
                    }
                    .tabItem {
                        Image(systemName: "plus.circle.fill")
                    }.tag(2)
                
                NotificationsView()
                    .onTapGesture {
                        selecteTab = 3
                    }
                    .tabItem {
                        Image(systemName: "bell")
                    }.tag(3)
                
                ProfileView(user: AuthenticationViewModel.shared.currentUser ?? user)
                                
                    .onTapGesture {
                        selecteTab = 4
                    }
                    .tabItem {
                        Image(systemName: "person.crop.circle")
                    }.tag(4)
            }
            .navigationTitle(tabTitle)
            .navigationBarItems(leading: logoutButton)
            .navigationBarTitleDisplayMode(.inline)
            .accentColor(tabColor)
        }
    }
    
    var logoutButton: some View {
        Button(action: {AuthenticationViewModel.shared.logout()}, label: {
            Text("Log out").foregroundColor(.red)
        })
    }
    
    var tabColor: Color {
        switch selecteTab {
        case 0:
            return .red
        case 1:
            return .pink
        case 2:
            return .green
        case 3:
            return .orange
        case 4:
            return .pink
        default:
            return .blue
        }
    }
    
    var tabTitle: String {
        switch selecteTab {
        case 0:
            return "What's hot"
        case 1:
            return "Search"
        case 2:
            return "Upload post"
        case 3:
            return "Notifications"
        case 4:
            return "Profile"
        default:
            return ""
        }
    }
    
}


