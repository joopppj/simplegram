
import SwiftUI
import Kingfisher
struct NotificationCell: View {
    @ObservedObject var viewModel: NotificationCellViewModel
    
    init(viewModel: NotificationCellViewModel) {
        self.viewModel = viewModel
    }
    
    @State private var showPostingImage = true
    var body: some View {
        HStack{
            KFImage(URL(string: viewModel.notification.profileImageUrl))
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
                .clipShape(Circle())
            
            VStack(alignment:.leading){
            Text(viewModel.notification.username).font(.system(size: 14, weight: .bold)) +
            Text(viewModel.notification.type.notificationMessage).font(.system(size: 15))
            
            Text("\(viewModel.timestampText) ago").foregroundColor(.gray).font(.system(size: 10))
            }
            Spacer()
            
            if viewModel.notification.type != .follow {
                if let post = viewModel.notification.post {
                    KFImage(URL(string: post.imageURL))
                        .resizable()
                        .scaledToFill()
                        .frame(width: 50, height: 50)
                        .clipped()
                }
            } else {
                Button(action: {
                    viewModel.notification.userFollowedBack ?? false ? viewModel.unfollowBack() : viewModel.followBack()
                }, label: {
                    Text(viewModel.notification.userFollowedBack ?? false ? "Following" : "Follow Back")
                        .font(.system(size: 16, weight: .semibold))
                        .frame(width: 120, height: 40, alignment: .center)
                        .foregroundColor(viewModel.notification.userFollowedBack ?? false ? .black : .white)
                        .background(viewModel.notification.userFollowedBack ?? false ? Color.white : Color.blue)
                        .overlay(RoundedRectangle(cornerRadius: 100)
                                    .stroke(Color.gray, lineWidth: viewModel.notification.userFollowedBack ?? false ? 3 : 0)
                        )
                }).cornerRadius(100)
            }
        }.padding(.horizontal,6)
    }
}

