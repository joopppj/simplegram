

import SwiftUI

struct ProfileButtonView: View {
    @ObservedObject var viewModel: ProfileViewModel
    //let isCurrentUser: Bool
    var isFollowed: Bool { return viewModel.user.isFollowed ?? false }
    
    var body: some View {
        if viewModel.user.isCurrentUser {
            /*Button(action: {}, label: {
                Text("Edit Profile")
                    .font(.system(size: 20, weight: .semibold, design: .serif))
                    .frame(width: 300, height: 40, alignment: .center)
                    .foregroundColor(.orange)
                    .overlay(RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.yellow, lineWidth: 2))
            })*/
        } else {
            HStack {
                Button(action: {
                        isFollowed ? viewModel.unfollow() : viewModel.follow()
                    //isFollowed.toggle() //unknown bug here
                }, label: {
                    Text(isFollowed ? "Following" : "Follow")
                        .font(.system(size: 20, weight: .semibold))
                        .frame(width: 145, height: 40, alignment: .center)
                        .foregroundColor(isFollowed ? .white : .white)
                        .background(isFollowed ? Color.blue : Color.blue)
                        .overlay(RoundedRectangle(cornerRadius: 100)
                                    .stroke(Color.gray, lineWidth: isFollowed ? 3 : 0)
                        )
                }).cornerRadius(100)
            
            
                Button(action: {}, label: {
                Text("Message")
                    .font(.system(size: 20, weight: .semibold, design: .serif))
                    .frame(width: 145, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.orange)
                    .overlay(RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.yellow, lineWidth: 2))
            })
            }
        }
    }
}
