
import SwiftUI
import Firebase
import Kingfisher
struct ProfileTopView: View {

    //let user: User
    @ObservedObject var viewModel: ProfileViewModel
    var body: some View {
        VStack(alignment: .leading){
            HStack {
                KFImage(
                    (URL(
                        string: viewModel.user.profileImageUrl
                    ))
                )
                    
                    .resizable()
                    .scaledToFill()
                    .frame(width: 90, height: 90)
                    .clipShape(Circle())
                    .padding(.leading)
                //.transition(.identity).animation(.easeIn(duration: 0))
                
                
                Spacer()
                
                FollowingPostsNumsView(PostsNum: viewModel.user.nums?.postNum ?? 0, FollowerNum: viewModel.user.nums?.followerNum ?? 0, FollowingNum: viewModel.user.nums?.followingNum ?? 0).padding(.trailing)
            }
            
            Text(viewModel.user.fullname)
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .padding([.leading, .top])
            
            /*Text("木葉の忍者")
                .font(.system(size: 15))
                .padding(.leading)
                .padding(.top, 1)*/
            
            HStack {
                Spacer()
                ProfileButtonView(viewModel: viewModel)
                Spacer()
            }.padding(.top)
        }
    }
}

struct FollowingPostsNumsView : View {
    var PostsNum : Int
    var FollowerNum : Int
    var FollowingNum : Int
    
    
    var body: some View {
        HStack {
            VStack{
                Text("\(PostsNum)")
                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                Text("Posts")
                    .font(.system(size: 15))
            }.frame(width: 80, height: 80, alignment: .center)
            
            VStack{
                Text("\(FollowerNum)")
                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                Text("Followers")
                    .font(.system(size: 15))
            }.frame(width: 80, height: 80, alignment: .center)
            
            VStack{
                Text("\(FollowingNum)")
                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                Text("Following")
                    .font(.system(size: 15))
            }.frame(width: 80, height: 80, alignment: .center)
        }
    }
}
