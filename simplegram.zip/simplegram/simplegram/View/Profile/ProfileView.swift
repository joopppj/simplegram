
import SwiftUI

struct ProfileView: View {
    var user: User
    @ObservedObject var viewModel: ProfileViewModel
    
    init(user: User) {
        self.user = user
        self.viewModel = ProfileViewModel(user: user)
    }
    var body: some View {
        ScrollView{
            VStack(spacing: 30){
                ProfileTopView(viewModel: viewModel)
                
                PostGridView(forType: .profile(uid: user.id ?? ""))
            }.padding(.top)
        }
    }
}


