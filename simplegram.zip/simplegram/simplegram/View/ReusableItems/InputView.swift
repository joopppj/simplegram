

import SwiftUI

struct InputView: View {
    @Binding var inputText: String
    
    var action: ()->Void
    
    var body: some View {
        VStack{
            
            Divider()
            /*Rectangle()
                .foregroundColor(Color(.separator))
                .frame(width: UIScreen.main.bounds.width, height: 1)
                .padding(.bottom, 4)*/
            
            HStack(spacing: 30){
                TextField("Comment here", text: $inputText )
                    .textFieldStyle(PlainTextFieldStyle())
                    .frame(minHeight: 30)
                
                Button(action:  action , label: {
                    Text("Send").bold().foregroundColor(.red)
                })
            }
            .padding()
        }
        
    }
}

struct InputView_Previews: PreviewProvider {
    static var previews: some View {
        InputView(inputText: .constant(""),action: {})
    }
}
