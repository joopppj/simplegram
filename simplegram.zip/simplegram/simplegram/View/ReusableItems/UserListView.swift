
import SwiftUI

struct UserListView: View {
    @ObservedObject var viewModel: SearchViewModel
    @Binding var searchingText: String
    var body: some View {
        ScrollView{
            LazyVStack(spacing: 20){
                ForEach(searchingText.isEmpty ? viewModel.users: viewModel.filterUser(searchingText)) { user in
                    NavigationLink(
                        destination: ProfileView(user: user),
                        label: {
                            UserCell(user: user)
                                .padding(.leading)
                        })
                }
            }
        }
    }
}

