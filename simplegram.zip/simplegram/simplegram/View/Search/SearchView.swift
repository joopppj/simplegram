

import SwiftUI

struct SearchView: View {
    
    @State var searchText = ""
    @State var isEditing = false
    
    @ObservedObject var viewModel = SearchViewModel()
    
    
    var body: some View {
        
        ScrollView{
            SearchBar(text: $searchText, isEditing: $isEditing)
                .padding()
            
            ZStack {
                if isEditing {
                    UserListView(viewModel: viewModel, searchingText: $searchText)
                } else {
                    PostGridView(forType: .whatshot)
                }
            }
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
