

import SwiftUI

struct UploadView: View {
    
    //@State private var selectedImage: UIImage?
    //@State var postImage: Image?
    @State var commentText = ""
    
    @State private var image = UIImage()
    
    @State private var isShowPhotoLibrary = false
    
    @ObservedObject var viewModel = PostViewModel()
    
    @Binding var selectedTab: Int
    
    var body: some View {
        
        VStack {
            if image == UIImage() {
                Button(action: {
                    self.isShowPhotoLibrary.toggle()
                }, label: {
                    Image("upload")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150, alignment: .center).clipped()
                        .padding(.top,100)
                })
                
            } else {
                HStack (alignment: .top){
                    Image(uiImage: self.image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 100)
                        .clipped()
                    
                    UploadTextEditor(commentText: $commentText, placeholder: "Please add description here")
                        .frame(maxHeight: 200)
                }.padding()
                
                HStack {
                    Button(action: { viewModel.UploadPost(text: commentText, image: image) { _ in
                            commentText = ""
                            image = UIImage()
                            selectedTab = 0
                    }
                    
                    }, label: {
                        Text("Share")
                            .font(.system(size: 15, weight: .semibold))
                            .frame(width: 150, height: 40)
                            .background(Color.blue)
                            .cornerRadius(100)
                            .foregroundColor(.white)
                }).padding()
                    
                    Button(action: {
                            commentText = ""
                            image = UIImage()
                            selectedTab = 2
                    }
                    , label: {
                        Text("Cancel")
                            .font(.system(size: 15, weight: .semibold))
                            .frame(width: 150, height: 40)
                            .background(Color.red)
                            .cornerRadius(100)
                            .foregroundColor(.white)
                    }).padding()
                }
                
                
            }
            Spacer()
        }.sheet(isPresented: $isShowPhotoLibrary, content: {
            ImagePicker(sourceType: .photoLibrary, selectedImage: self.$image)
        })
    }
}

