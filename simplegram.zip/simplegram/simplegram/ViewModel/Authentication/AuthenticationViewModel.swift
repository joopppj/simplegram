// view model here for authentication

import Foundation
import SwiftUI
import Firebase


class AuthenticationViewModel: ObservableObject {
    @Published var userSession: Firebase.User?
    static let shared = AuthenticationViewModel()
    @Published var currentUser: User?
    @Published var sentResetPasswordLink : Bool = false
    

    init() {
        userSession = Auth.auth().currentUser
        fetchUser()
    }
    func login(email: String, password: String) {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if error != nil {
                print(error!.localizedDescription)
                return
            }
            guard let user = result?.user else {
                print(" something goes wrong when getting user")
                return
            }
            
            self.userSession = user
            self.fetchUser()
            //self.currentUser = user
        }
        //fetchUser()
    }
    
    func logout() {
        self.userSession = nil  // go back to login view
        try! Auth.auth().signOut() // sign out user on firebase
    }
    func resetPassword(withEmail email: String)  {
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            if let error = error {
                print("Error: password reset failed due to \(error.localizedDescription)")
                return
            }
            self.sentResetPasswordLink = true
        }
    }
    
    func signup(email: String, username: String, password: String, image: UIImage, fullname: String) {
        ImageUploader.uploadImage(image: image, UploadFor: .profile) { imageUrl in
            Auth.auth().createUser(withEmail: email, password: password){ result , error in
                if error != nil {
                    print(error!.localizedDescription)
                    return
                }
                
                guard let user = result?.user else {
                    print(" something goes wrong when getting user")
                    return
                }
                
                self.userSession = user
                print("successfully signed up a user with email \(email)")
                let data = ["email": email,
                            "username": username,
                            "fullname": fullname,
                            "profileImageUrl": imageUrl,
                            "uid": user.uid]
                
                COLLECTION_USERS.document(user.uid).setData(data) { _ in
                    print("successfully registered user data ")
                    //self.userSession = user
                    self.fetchUser()
                }
            }
        }
        
        //fetchUser() bug
    }
    
    // get usersession uid to get make a User object of current user, also change the currentUser var,  so other parts of project can follow
    func fetchUser() {
        guard let uid = userSession?.uid else { return }
        COLLECTION_USERS.document(uid).getDocument { DocumentSnapshot, _ in
            guard let user = try? DocumentSnapshot?.data(as: User.self) else {return }
            self.currentUser = user
            print("DEBUG: User is \(user)")
        }
    }
    
}
