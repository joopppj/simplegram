import SwiftUI

class FeedCellViewModel: ObservableObject {
    @Published var post: Post
    
    var timestampText: String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.second, .minute, .hour, .day]
        formatter.maximumUnitCount = 1
        formatter.unitsStyle = .short
        return formatter.string(from: post.timestamp.dateValue(), to: Date()) ?? "" // difference between post time and now.
    }
    
    init(post: Post) {
        self.post = post
        fetchIsLiked()
    }
    
    func like() {
        //guard let postId = post.id else { return }
        print("successfully liked this post \(post.text)")
        
        guard let uid = AuthenticationViewModel.shared.userSession?.uid else { return }
        
        COLLECTION_POSTS.document(post.id ?? "").collection("post-liked-by").document(uid).setData([:]){_ in
            COLLECTION_USERS.document(uid).collection("liked-posts")
                .document(self.post.id ?? "").setData([:]){_ in
                    COLLECTION_POSTS.document(self.post.id ?? "").updateData(["likes": self.post.likes + 1])
                    
                    NotificationViewModel.uploadNotification(receiver: self.post.authorUid, type: .like, post: self.post) // send notification to firebase
                    
                    
                    self.post.liked = true
                    self.post.likes += 1
                }
        }
    }
    
    func unlike()  {
        if post.likes <= 0 {return}
        print("disliked this post ")
        guard let uid = AuthenticationViewModel.shared.userSession?.uid else { return }
    
        COLLECTION_POSTS.document(post.id ?? "").collection("post-liked-by").document(uid).delete {_ in
            COLLECTION_USERS.document(uid).collection("liked-posts")
                .document(self.post.id ?? "").delete {_ in
                    COLLECTION_POSTS.document(self.post.id ?? "").updateData(["likes": self.post.likes - 1])
                    
                    self.post.liked = false
                    self.post.likes -= 1
                }
        }
    }
    
    func comment() {
        
    }
    
    func fetchIsLiked() {
        guard let uid = AuthenticationViewModel.shared.userSession?.uid else { return }
    
        COLLECTION_USERS.document(uid).collection("liked-posts").document(self.post.id ?? "").getDocument { DocumentSnapshot, _ in
            guard let liked = DocumentSnapshot?.exists else { return }
            self.post.liked = liked
        }
    
    }
}

