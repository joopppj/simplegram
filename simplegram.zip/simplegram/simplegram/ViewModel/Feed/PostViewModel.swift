import Foundation
import SwiftUI
import Firebase

class PostViewModel: ObservableObject {
    
    func UploadPost(text: String, image: UIImage, completion: @escaping (Error?) -> Void) {
        guard let user = AuthenticationViewModel.shared.currentUser else { return }
        
        ImageUploader.uploadImage(image: image, UploadFor: .post) { imageURL in
            let data = ["text": text,
                        "imageURL": imageURL,
                        "timestamp": Timestamp(),
                        "likes": 0,
                        "authorUid": user.id!, // DEBUG: potential error
                        "authorProfileImageUrl": user.profileImageUrl,
                        "authorUsername": user.username
                        
            ] as [String : Any]
            
            COLLECTION_POSTS.addDocument(data: data, completion: completion)
            print("success post to firebase")
       
        }
    }
}
