import SwiftUI
import Firebase

class GridViewModel: ObservableObject{
    @Published var posts = [Post]()
    let forType: PostsCollectionFor
    
    
    init(forType: PostsCollectionFor) {
        self.forType = forType
        fetchPosts(forType: forType)
    }
    
    func fetchPosts(forType: PostsCollectionFor)  {
        switch forType {
        case .profile(let uid):
            fetchProfilePosts(forUid: uid)
        case .whatshot:
            fetchAllPosts()
        }
    }
    func fetchAllPosts()  {
        COLLECTION_POSTS.getDocuments { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }
            self.posts = documents.compactMap { queryDocumentSnapshot -> Post? in
                return try? queryDocumentSnapshot.data(as: Post.self)
                }
            print(self.posts)
        }
    }
    
    func fetchProfilePosts(forUid uid: String) {
        COLLECTION_POSTS.whereField("authorUid", isEqualTo: uid).getDocuments { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }
            self.posts = documents.compactMap { queryDocumentSnapshot -> Post? in
                return try? queryDocumentSnapshot.data(as: Post.self)
                }
            print(self.posts)
        }
    }
}

enum PostsCollectionFor {
    case profile(uid:String)
    case whatshot
}
