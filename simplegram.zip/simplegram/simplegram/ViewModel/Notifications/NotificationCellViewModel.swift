import SwiftUI

class NotificationCellViewModel: ObservableObject {
    @Published var notification: Notification
    
    var timestampText: String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.second, .minute, .hour, .day]
        formatter.maximumUnitCount = 1
        formatter.unitsStyle = .short
        return formatter.string(from: notification.timestamp.dateValue(), to: Date()) ?? "" // difference between post time and now. // potential bug here , but looks fine now
    }
    
    init(notification: Notification) {
        self.notification = notification
        checkIfNotificationUserFllowed()
        fetchNotificationPost()
    }
    
    func followBack() {
        Services.follow(uid: notification.uid) { _ in // this is the completion function passed to services.follow()
                self.notification.userFollowedBack = true // keep track of if the profile is followed by current user
                
            NotificationViewModel.uploadNotification(receiver: self.notification.uid, type: .follow)
                //print("successfully followed this user \(self.user.username) from back-end and uploaded the notification to firebase")
            }
    }
    
    func unfollowBack() {
        Services.unfollow(uid: notification.uid) { _ in // this is the completion function passed to services.follow()
                self.notification.userFollowedBack = false // keep track of if the notification user is followed by current user
                //print("successfully unfollowed this user \(self.notification.uid.username) from back-end ")
            }
    }
    
    func checkIfNotificationUserFllowed()  {
        guard notification.type == .follow else { return }
        Services.isProfileUserFllowed(uid: notification.uid) { isFollowed in
            self.notification.userFollowedBack = isFollowed
            }
    }
    
    func fetchNotificationPost() {
        guard let postId = notification.postId else { return }
        
        COLLECTION_POSTS.document(postId).getDocument { documentSnapshot , _ in
            self.notification.post = try? documentSnapshot?.data(as: Post.self)
        }
    }
}
