
import SwiftUI
import Firebase
class NotificationViewModel: ObservableObject {
    @Published var notifications = [Notification]()
    
    init() {
        fetchNotifications()
    }
    
    func fetchNotifications() {
        guard let uid = AuthenticationViewModel.shared.currentUser?.id else { return }
        
        let query = COLLECTION_NOTIFICATIONS.document(uid).collection("user-notifications").order(by: "timestamp", descending: true)
        
        
        query.getDocuments { documentSnapshot, _ in
            self.notifications = (documentSnapshot?.documents.compactMap({ QueryDocumentSnapshot -> Notification? in
                return try? QueryDocumentSnapshot.data(as: Notification.self)
            }))!// some error here
            print("successfully fetched notification ")
            print(self.notifications)
        }
    }
    
    
    static func uploadNotification(receiver uid: String, type: NotificationType, post: Post? = nil){
        guard let user = AuthenticationViewModel.shared.currentUser else {return} // sender of notification
        guard uid != user.id else { return }
        var data: [String : Any] = ["username" : user.username,
                    "profileImageUrl": user.profileImageUrl,
                    "uid": user.id ?? "",
                    "timestamp": Timestamp(date: Date()),
                    "type": type.rawValue]
        
        if post != nil {     // add post uid
            let id = post?.id ?? ""
            data["postId"] = id
        }
        
        COLLECTION_NOTIFICATIONS.document(uid).collection("user-notifications").addDocument(data: data)
        
        
    }
}
