import SwiftUI
import Firebase

class ProfileViewModel: ObservableObject {
    @Published var user: User
    
    init(user: User) {
        self.user = user
        isProfileUserFllowed()
        fetchUserNums()
    }
    
    func follow() {
        if let uid = user.id {
            Services.follow(uid: uid) { _ in // this is the completion function passed to services.follow()
                self.user.isFollowed = true // keep track of if the profile is followed by current user
                
                NotificationViewModel.uploadNotification(receiver: uid, type: .follow)
                print("successfully followed this user \(self.user.username) from back-end and uploaded the notification to firebase")
            }
        }  else {
            print("something goes wrong when getting the uid of the profile user ")
            return
        }
        
    }
    
    func unfollow() {
        if let uid = user.id {
            Services.unfollow(uid: uid) { _ in // this is the completion function passed to services.follow()
                self.user.isFollowed = false // keep track of if the profile is followed by current user
                print("successfully unfollowed this user \(self.user.username) from back-end ")
            }
        }  else {
            print("something goes wrong when getting the uid of the profile user ")
            return
        }
    }
    
    func isProfileUserFllowed()  {
        
        
        if let uid = user.id {
            Services.isProfileUserFllowed(uid: uid) { isFollowed in
                self.user.isFollowed = isFollowed
            }
        } else {
            print("something goes wrong when getting the uid of the profile user ")
            return
        }
    }
    
    func fetchUserNums() {
        guard let uid = user.id else { return }
        
        COLLECTION_FOLLOWINGS.document(uid).collection("followings").getDocuments { querySnapshot, _ in
            guard let followingNum = querySnapshot?.documents.count else { return }
            
            COLLECTION_FOLLOWERS.document(uid).collection("followers").getDocuments { querySnapshot1, _ in
                guard let followerNum = querySnapshot1?.documents.count else { return }
                
                COLLECTION_POSTS.whereField("authorUid", isEqualTo: uid).getDocuments { querySnapshot2, _ in
                    guard let postNum = querySnapshot2?.documents.count else { return }
                    self.user.nums = userNumbers(postNum: postNum, followingNum: followingNum, followerNum: followerNum)
                   //print(" the usernums is \(self.user.nums) ")
                }
            }
        }
    }
}
