

import Foundation
import Firebase
import SwiftUI

class SearchViewModel: ObservableObject {
    @Published var users = [User]()
    //@Published var posts = [Post]()
    
    init() {
        fetchUsers()
        //fetchPosts()
    }
    
    // get all users in database
    func fetchUsers()  {
        COLLECTION_USERS.getDocuments { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }
        
            //self.users = try! documents.compactMap({try? $0.data(as: User.self)})
            self.users = documents.compactMap { queryDocumentSnapshot -> User? in
                  return try? queryDocumentSnapshot.data(as: User.self)
                }
            print(self.users)
        }
        
    }
    
    /*func fetchPosts()  {
        COLLECTION_POSTS.getDocuments { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }
            self.posts = documents.compactMap { queryDocumentSnapshot -> Post? in
                return try? queryDocumentSnapshot.data(as: Post.self)
                }
            print(self.posts)
        }
    }*/
    
    func filterUser(_ query: String) -> [User] {
        let lowercasedQuery = query.lowercased()
        return users.filter { (User) -> Bool in
            User.username.lowercased().contains(lowercasedQuery)
        }
    }
}
