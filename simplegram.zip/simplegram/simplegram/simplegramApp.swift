//
//  simplegramApp.swift
//  simplegram
//
//  Created by zhousenyeliu on 2021/03/04.
//

import SwiftUI
import Firebase

@main
struct simplegramApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(AuthenticationViewModel.shared)
        }
    }
}
